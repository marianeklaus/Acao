# Projeto de algoritimos

O algoritmo da classe Ação será representado pelo método negociar(), mas ele não será implementado nesse momento.