# Projeto de Dados

- Os dados inseridos pelo usuário serão lidos por meio de uma LISTA.
- A partir
