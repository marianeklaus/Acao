# Projeto de Arquitetura

Este aplicativo será desenvolvido utilizando programação orientada a objetos e a Ação será representada por um objeto que possui com as seguintes características

1. Atributos:

- Emissor
- Código

2. Funcionalidades

- negociar()

- Modelo de Entrada e Saída de dados

Módulo de entrada: usuário inserirá as características da ação.

Módulo de saída: informará ao usuário que foi criado o objeto computacional que representa a ação.

- Módulo de Processamento

Este módulo instanciará um objeto com as características inseridas pelo usuário.


