# Plano de codificaçõ e Testes

O método de codificação e testes utilizado será o RDD.