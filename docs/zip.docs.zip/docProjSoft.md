# Documento de Projeto de Software 

##![Projeto de arquitetura](projArq.md)

##![Projeto de Dados](projDados.md)

##![Projeto de Algoritmos](projAlg.md)

##![Plano de codificação e Testes](planoCodTestes.md)