# Projeto Desenvolvimento de Aplicativo de Modelagem do Mercado de Ações na B3

## Problema

Aplicativo que modele ações no mercado da B3.

Gravar dados de um papel.

Atributos ação: razão social (emissor), código B3

Funcionalidades: negociar (compra/venda).